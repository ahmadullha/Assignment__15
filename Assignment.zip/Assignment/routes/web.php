<?php

use App\Http\Requests\RegistrationFormRequest;
use App\Http\Requests\RegistrationRequestController;
use App\Http\Middleware\AuthMiddleware;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Task 2: Request Redirect

Route::get('/dashboard', function () {
    return view('page.dashboard');
});

Route::get('/home', function () {
    return redirect('/dashboard', 302);
});


// Task 4: Route Middleware

Route::middleware(['AuthMiddleware::class'])->group(function () {
    Route::get('/profile', function () {
        // Logic for the /profile route
    });

    Route::get('/settings', function () {
        // Logic for the /settings route
    });
});

//..............
Route::get('/contact',function(){
    return view('page.contact');
    });
Route::post('/sendmail', ContactController::class);
//...........

Route::resource('products', 'ProductController');
//.............

Route::resource('posts', 'PostController');
