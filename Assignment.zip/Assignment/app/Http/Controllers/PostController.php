<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    // Task 7: Resource Controller
    public function index()
    {
        // Logic for displaying a list of all posts
    }

    public function create()
    {
        // create a new post
    }

    public function store(Request $request)
    {
        // storing a newly created post
    }

    public function show($id)
    {
        // displaying a specific post
    }

    public function edit($id)
    {
        //...
    }

    public function update(Request $request, $id)
    {
        //.....
    }

    public function destroy($id)
    {
        // deleting the specified post
    }
}
