<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <nav>
        <!-- Add your navigation bar code here -->
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>

    <section>
        <h1>Welcome to Laravel!</h1>
    </section>
</body>
</html>




{{-- Task 8: Blade Template Engine

@extends('Layout.app')

@section('title', 'Home Page')
@section('description', 'this is homepage Description')
@section('keyowrds','comma, separated, list, of, relevant, keywords')

@section('content')
   @include('component.welcomehero')
@endsection

