<style>
    .hero {
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #f8fafc;
        color: #636b6f;
        font-size: 2em;
        text-align: center;
    }
</style>

<section class="hero">
    <div>
        <h1>Welcome to Laravel</h1>
    </div>
</section>
